import UIKit



func responseTo(question: String) -> String {
    
    let lowerQuestion = question.lowercased()
    
    if lowerQuestion == "where are you from?" {
        return "Detroit, Michigan!"
    } else if lowerQuestion.hasPrefix("where") {
        return "The MidWest!"
    } else {
      
        let defaultNumber = question.count % 3
        
        if defaultNumber == 0 {
            return "I do not have the answer to that question"
        } else {
            return "That Location is unknown to me"
        }

    }
}
responseTo(question: "Where are you from?")
responseTo(question: "Do you know where starbucks is located?")
responseTo(question: "PLEASE tell me about the rocky mountains?")
